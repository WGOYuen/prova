package arquivo;

public class Status extends Jogador {
	 
	private int id;
	
	   public int getId() {
	   return id;
	 }
	
	public Status(String nome, String raca, int id) {
		super();
		this.id = id;

	}
	
	
}

