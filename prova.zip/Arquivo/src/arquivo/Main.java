package arquivo;

public class Main {
	 
	static Jogador md =new Jogador();
	static Castelo c3 = new Castelo(0, 0, md);
	static arma arm =new arma();
	static tesouro t1 =new tesouro();
	static tesouro t2 =new tesouro();
	static tesouro t3 =new tesouro();
	

	public static void main(String[] args) {
	
		md.setNome("will");
		md.setRaca("HUMANO");
	
		c3.setVida(200);
		c3.setPoderDef(70);
		
		t1.setValor(30);
		t1.setTipotesouro("Bronze");
		
		t2.setValor(50);
		t2.setTipotesouro("Prata");
		
		t3.setValor(100);
		t3.setTipotesouro("Ouro");
		
		
		System.out.println(".          ___Personagem___       .");
		System.out.println(".   "+   md.getNome() + "   "+ md.getRaca()+"      .");
		System.out.println("._________________________________.");
		
		
		System.out.println(" .  .   .  .   .   .   .  . .");
		System.out.println(".      ___Castelo__         .");
		System.out.println(".    __________________     .");
		System.out.println("_____________________________");
		System.out.println(c3.getPoderDef());
		System.out.println("_____________________________");
		
		System.out.println("_____________________________");
		System.out.println("________ Masmorra ___________");
		System.out.println("_____________________________");
		System.out.println("  "+t1.getTipotesouro());
		System.out.println("  "+t2.getTipotesouro());
		System.out.println("  "+t3.getTipotesouro());
		
		
		
		
		
		
		
		
		
		
	}

}
