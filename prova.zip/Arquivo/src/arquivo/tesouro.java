package arquivo;

public class tesouro{
	private float valor;
	private String tipotesouro;

  public boolean getvalor(){
	  return false;
	
}

public float getValor() {
	return valor;
}

public void setValor(float valor) {
	this.valor = valor;
}

public String getTipotesouro() {
	return tipotesouro;
}

public void setTipotesouro(String tipotesouro) {
	this.tipotesouro = tipotesouro;
}

}
