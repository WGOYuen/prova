package arquivo;

public class Castelo extends Jogador{
 private int vida;
 private int poderDef;
private Object arma;

public Castelo(int vida,int poderDef,Object arma) {
this.vida=vida;
this.poderDef=poderDef;
this.setArma(arma);
}

public int getVida() {
	return vida;
}

public void setVida(int vida) {
	this.vida = vida;
}

public int getPoderDef() {
	return poderDef;
}

public void setPoderDef(int poderDef) {
	this.poderDef = poderDef;
}

public Object getArma() {
	return arma;
}

public void setArma(Object arma) {
	this.arma = arma;
}
}
