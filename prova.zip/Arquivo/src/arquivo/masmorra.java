package arquivo;

public class masmorra {
	
   String tipo, nivelDificuldade;
   int Ouroencontrado;
   
   
   void relatorio(String tipo,String nivelDificuldade) {
	   this.tipo=tipo;
	   this.nivelDificuldade =nivelDificuldade;
   }
}
