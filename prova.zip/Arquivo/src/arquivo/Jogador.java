package arquivo;

public class Jogador {
	  
     private String nome;
     private String raca;
     private arma Armamento;
	 	
    
    void CalcularTotal() {
    	
    }
    

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public String getRaca() {
	return raca;
}

public void setRaca(String raca) {
	this.raca = raca;
}


public arma getArmamento() {
	return Armamento;
}


public void setArmamento(arma armamento) {
	Armamento = armamento;
}
	
}
