package arquivo;

public class arma {
	public enum tipoa{
		ESPADA,MACHADO,ARCOEFLECHA
	}
}
	